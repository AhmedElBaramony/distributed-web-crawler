import time
import logging
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from whoosh.fields import Schema, TEXT, ID
from whoosh.index import create_in
import os
from sqs_config import (
    CRAWL_QUEUE_URL,
    HEARTBEAT_QUEUE_URL,
    RESULT_QUEUE_URL,
    send_message_sqs,
    receive_messages_sqs,
    delete_parsed_message_sqs,
)

EXCLUDED_EXTENSIONS = ('.pdf', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.zip', '.mp4', '.doc', '.docx', '.xls', '.xlsx')

# ===============================
# Logging Setup
# ===============================
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("Crawler")

# ===============================
# Whoosh Index Setup
# ===============================
if not os.path.exists("indexdir"):
    os.mkdir("indexdir")

schema = Schema(url=ID(stored=True, unique=True), content=TEXT)
ix = create_in("indexdir", schema)

# ===============================
# Helper Functions
# ===============================

def extract_links_and_text(html, base_url):
    """
    Parses HTML content and extracts:
    - A list of absolute hyperlinks
    - The visible text content
    """
    soup = BeautifulSoup(html, 'html.parser')
    all_links = [urljoin(base_url, a.get('href')) for a in soup.find_all('a', href=True)]

    # Filter out unwanted file types
    valid_links = []
    for link in all_links:
        parsed = urlparse(link)
        if not parsed.path.lower().endswith(EXCLUDED_EXTENSIONS):
            valid_links.append(link)

    text = soup.get_text()
    return valid_links, text.strip()

def index_with_whoosh(url, text):
    """
    Indexes the given URL and its visible text using Whoosh.
    """
    writer = ix.writer()
    writer.update_document(url=url, content=text)
    writer.commit()
    logger.info(f"[Whoosh] Indexed: {url}")

def send_heartbeat(worker_id):
    """
    Sends a heartbeat message to notify the master this crawler is alive.
    """
    payload = {"worker_id": worker_id}
    send_message_sqs(HEARTBEAT_QUEUE_URL, "heartbeat", payload)

# ===============================
# Main Crawler Loop
# ===============================

def main():
    worker_id = f"crawler-{int(time.time())}" # Unique worker ID
    logger.info(f"[Crawler] Starting as {worker_id}")

    while True:
        send_heartbeat(worker_id)  # notify master this crawler is alive

        messages = receive_messages_sqs(CRAWL_QUEUE_URL, max_messages=1, wait_time=5)
        if not messages:
            time.sleep(2)
            continue

        for msg in messages:
            task = msg["payload"]
            url = task.get("url")
            depth = task.get("depth", 0)
            task_id = task.get("task_id")

            if not url:
                logger.warning("Received task without URL.")
                delete_parsed_message_sqs(CRAWL_QUEUE_URL, msg)
                continue

            logger.info(f"[Crawler] Crawling: {url} (depth {depth})")

            try:
                response = requests.get(url, timeout=10)
                links, text = extract_links_and_text(response.text, url)
                index_with_whoosh(url, text)

                result_payload = {
                    "url": url,
                    "source_depth": depth,
                    "new_urls": links,
                    "task_id": task_id
                }

                send_message_sqs(RESULT_QUEUE_URL, "crawl_result", result_payload)
                logger.info(f"[Crawler] Sent crawl result for: {url} with {len(links)} links")

            except Exception as e:
                logger.error(f"[Crawler] Error crawling {url}: {e}")

            delete_parsed_message_sqs(CRAWL_QUEUE_URL, msg)

        time.sleep(1)  # be nice to the CPU and the web servers

if __name__ == '__main__':
    main()