from flask import Flask, render_template, jsonify, request, send_file
from collections import defaultdict, deque
from subprocess import Popen
import time, threading, os

from whoosh.index import open_dir
from whoosh.qparser import QueryParser
from whoosh import scoring

app = Flask(__name__)

# In-memory store for logs
MAX_LOG_LINES = 200
logs = defaultdict(lambda: deque(maxlen=MAX_LOG_LINES))

# Real heartbeat and metric stores
heartbeat_status = {}
heartbeat_counts = defaultdict(int)
pages_crawled = defaultdict(int)
urls_indexed = defaultdict(int)

# Node config
NODE_IDS = ["master", "indexer", "crawler1", "crawler2", "combined"]
node_roles = {
    "master": "master",
    "indexer": "indexer",
    "crawler1": "crawler",
    "crawler2": "crawler"
}

queue_info = {"queued_tasks": 0, "active_crawls": 0}

# Background thread: expire offline heartbeats
def auto_cleanup():
    while True:
        time.sleep(5)
        now = time.time()
        for node, role in node_roles.items():
            if (now - heartbeat_status.get(node, 0)) > 10:
                heartbeat_status[node] = 0

threading.Thread(target=auto_cleanup, daemon=True).start()

@app.route("/")
def index():
    return render_template("index.html", node_ids=NODE_IDS, node_roles=node_roles)

@app.route("/api/logs/<node>", methods=["GET", "POST"])
def handle_logs(node):
    if request.method == "GET":
        return jsonify(list(logs[node]))
    
    msg = request.args.get("msg", "")
    print(f"[DEBUG] Received log for {node}: {msg}")
    if not msg.strip():
        return "empty", 400

    for line in msg.splitlines():
        timestamp = time.strftime("%H:%M:%S")
        entry = f"[{timestamp}] {line}"
        logs[node].append(entry)
        logs["combined"].append(f"[{timestamp}] ({node}) {line}")
    
    return "ok"

@app.route("/api/heartbeat/<node>", methods=["GET"])
def heartbeat(node):
    heartbeat_status[node] = time.time()
    heartbeat_counts[node] += 1
    return "OK"

@app.route("/api/pagecount/<node>", methods=["POST"])
def update_pages_crawled(node):
    pages_crawled[node] += 1
    return "OK"

@app.route("/api/indexed/<node>", methods=["POST"])
def update_indexed(node):
    urls_indexed[node] += 1
    return "OK"

@app.route("/api/metrics")
def get_metrics():
    now = time.time()
    metrics = {
        "heartbeat_status": {},
        "heartbeat_counts": {},
        "pages_crawled": {},
        "urls_indexed": {},
        "queue": queue_info
    }

    for node, role in node_roles.items():
        is_online = (now - heartbeat_status.get(node, 0)) < 10
        metrics["heartbeat_status"][node] = "online" if is_online else "offline"

        if is_online:
            if role == "crawler":
                metrics["heartbeat_counts"][node] = heartbeat_counts[node]
                metrics["pages_crawled"][node] = pages_crawled[node]
            elif role == "indexer":
                metrics["urls_indexed"][node] = urls_indexed[node]
        else:
            logs[node].clear()
            if role == "crawler":
                pages_crawled[node] = 0
                heartbeat_counts[node] = 0
            elif role == "indexer":
                urls_indexed[node] = 0

    return jsonify(metrics)

@app.route("/api/download/<node>")
def download_logs(node):
    filename = f"logs_{node}.txt"
    with open(filename, "w") as f:
        f.write("\n".join(logs[node]))
    return send_file(filename, as_attachment=True)

# ✅ SEARCH ENDPOINT + FUNCTION
def search_index(query_string):
    try:
        ix = open_dir("s3_indexdir")
    except Exception as e:
        return [f"Error opening index: {e}"]

    results = []
    with ix.searcher(weighting=scoring.BM25F()) as searcher:
        parser = QueryParser("content", schema=ix.schema)
        query = parser.parse(query_string)
        hits = searcher.search(query, limit=20)
        for hit in hits:
            url = hit.get("url", "Unknown URL")
            results.append(url)
    return results

@app.route("/api/search")
def search():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify([])
    return jsonify(search_index(query))

if __name__ == "__main__":
    app.run(debug=True)