import time
import logging
import os
import requests
from whoosh.index import create_in, open_dir
from whoosh.fields import Schema, TEXT, ID
from sqs_config import RESULT_QUEUE_URL, receive_messages_sqs, delete_parsed_message_sqs, download_from_s3
from dashboard_logger import start_heartbeat, DashboardLogHandler

# ==== Logging Setup ====
NODE_ID = "indexer"
DASHBOARD_HOST = "http://127.0.0.1:5000"  # Or ngrok URL
start_heartbeat(NODE_ID)

logger = logging.getLogger("Indexer")
logger.setLevel(logging.INFO)

# Console handler (stdout)
console_handler = logging.StreamHandler()
console_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))

# Dashboard handler (custom HTTP handler)
dashboard_handler = DashboardLogHandler(NODE_ID)
dashboard_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))

# Attach both handlers
logger.addHandler(console_handler)
logger.addHandler(dashboard_handler)

# ==== Whoosh Index Setup ====
if not os.path.exists("indexdir"):
    os.mkdir("indexdir")

schema = Schema(url=ID(stored=True, unique=True), content=TEXT(stored=True))
if not os.listdir("indexdir"):
    ix = create_in("indexdir", schema)
else:
    ix = open_dir("indexdir")

def index_url(url, content):
    writer = ix.writer()
    writer.update_document(url=url, content=content)
    writer.commit()
    logger.info(f"[Whoosh] Indexed: {url}")
    requests.post(f"{DASHBOARD_HOST}/api/indexed/indexer")

# ==== Main Indexer Loop ====
def main():
    logger.info("[Indexer] Started and listening for crawl results...")

    while True:
        messages = receive_messages_sqs(RESULT_QUEUE_URL, max_messages=5)

        if not messages:
            time.sleep(2)
            continue

        for msg in messages:
            payload = msg.get("payload", {})
            s3_key = payload.get("s3_key")

            if s3_key:
                try:
                    url, content = download_from_s3(s3_key)
                    index_url(url, content)
                except Exception as e:
                    logger.error(f"[Indexer] Failed to index {url}: {e}")

            delete_parsed_message_sqs(RESULT_QUEUE_URL, msg)

        time.sleep(1)

if __name__ == "__main__":
    main()