# dashboard_logger.py
import requests
import urllib.parse
import threading
import time
import logging

DASHBOARD_HOST = "http://127.0.0.1:5000"
LOG_ENDPOINT = "/api/logs/{node}?msg={msg}"
HEARTBEAT_ENDPOINT = "/api/heartbeat/{node}"

def log(node, message):
    for line in message.splitlines():
        try:
            safe_msg = urllib.parse.quote(line)
            url = f"{DASHBOARD_HOST}{LOG_ENDPOINT.format(node=node, msg=safe_msg)}"
            requests.get(url, timeout=1)
        except Exception:
            pass  # Fail silently

def start_heartbeat(node, interval=5):
    def beat():
        while True:
            try:
                requests.get(f"{DASHBOARD_HOST}{HEARTBEAT_ENDPOINT.format(node=node)}", timeout=1)
            except Exception:
                pass
            time.sleep(interval)
    thread = threading.Thread(target=beat, daemon=True)
    thread.start()

class DashboardLogHandler(logging.Handler):
    def __init__(self, node):
        super().__init__()
        self.node = node

    def emit(self, record):
        try:
            msg = self.format(record)
            log(self.node, msg)
        except Exception:
            pass