const nodeIds = ["master", "indexer", "crawler1", "crawler2", "combined"];
const POLL_INTERVAL_MS = 3000;

document.addEventListener("DOMContentLoaded", () => {
  pollLogs();
  pollMetrics();
  setInterval(pollLogs, POLL_INTERVAL_MS);
  setInterval(pollMetrics, POLL_INTERVAL_MS);
});

// Fetch and update logs
function pollLogs() {
  nodeIds.forEach(nodeId => {
    fetch(`/api/logs/${nodeId}`)
      .then(res => res.json())
      .then(data => {
        const logBox = document.getElementById(`log-${nodeId}`);
        if (logBox) {
          logBox.innerText = data.join("\n");
          logBox.scrollTop = logBox.scrollHeight;
        }
      });
  });
}

// Fetch and update metrics/status
function pollMetrics() {
  fetch("/api/metrics")
    .then(res => res.json())
    .then(data => {
      const panel = document.getElementById("status-panel");
      panel.innerHTML = "";
      const statuses = data.heartbeat_status;
      const crawled = data.pages_crawled;
      const indexed = data.urls_indexed;
      const heartbeats = data.heartbeat_counts;
      const queue = data.queue;

      nodeIds.filter(id => id !== "combined").forEach(node => {
        const status = statuses[node] === "online" ? "🟢 Running" : "🔴 Offline";
        const statusClass = statuses[node] === "online" ? "online" : "offline";
        const html = `
          <div class="col-md-3">
            <div class="card mb-2">
              <div class="card-body p-2">
                <h6 class="card-title">${node.toUpperCase()}</h6>
                <p class="mb-1 status-indicator ${statusClass}">${status}</p>
                <p class="mb-1">💓 Heartbeats: ${heartbeats[node] || 0}</p>
                <p class="mb-1">📄 Pages Crawled: ${crawled[node] || 0}</p>
                <p class="mb-0">📦 URLs Indexed: ${indexed[node] || 0}</p>
              </div>
            </div>
          </div>
        `;
        panel.insertAdjacentHTML("beforeend", html);
      });

      // Append queue info
      const queueHTML = `
        <div class="col-md-3">
          <div class="card mb-2 bg-warning-subtle">
            <div class="card-body p-2">
              <h6 class="card-title">Queue Info</h6>
              <p class="mb-1">🕒 Queued Tasks: ${queue.queued_tasks}</p>
              <p class="mb-0">🚀 Active Crawls: ${queue.active_crawls}</p>
            </div>
          </div>
        </div>`;
      panel.insertAdjacentHTML("beforeend", queueHTML);
    });
}

// Button actions
function startNode(node) {
  fetch(`/api/start/${node}`)
    .then(res => res.json())
    .then(data => alert(`${node} started: ${data.status}`));
}

function stopNode(node) {
  fetch(`/api/stop/${node}`)
    .then(res => res.json())
    .then(data => alert(`${node} stopped: ${data.status}`));
}

function downloadLogs(node) {
  window.open(`/api/download/${node}`, "_blank");
}